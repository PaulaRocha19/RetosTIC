 package com.rentamaquina.maquinaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaquinariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaquinariaApplication.class, args);
	}

}
